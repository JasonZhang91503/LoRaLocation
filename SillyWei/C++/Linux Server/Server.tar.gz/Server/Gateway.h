#ifndef _GATEWAY_H
#define _GATEWAY_H

#include "Server.h"

class CarInfo{
public:
    int id;
    int packageNum;
    int intMessageSize;
    char buff[BUFFSIZE];
    char message[BUFFSIZE];

    void changePackageNum() {
        if (packageNum == 1) {
            packageNum = 2;
        }else if (packageNum == 2) {
            packageNum = 1;
        }
    }
};

void handleGatewayFront(int intSocketClient);
void stateUpdate(int id, int state);

void handleGatewayBack();
void getNewTransport(vector<string> &message);
void gatewayBackgroundSend(string message);
void gatewaySleep();
// Find carInfo with id, if exist return the index, else return -1
int findCarInfo(int id, vector<CarInfo> carInfo);
int findSocket(int clientSocket);

#endif
