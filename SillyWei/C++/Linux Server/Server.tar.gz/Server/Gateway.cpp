#include "Gateway.h"
#include "Server.h"
#include "Socket.h"

vector<int> socketGateway;
vector<CarInfo> carInfoSend;
vector<CarInfo> carInfoReceive;

void handleGatewayFront(int clientSocket) {
    cout << "Function handleGatewayFront start" << endl;

    int errorCode;
	int index;
	cout << "Start gateway task" << endl;

	socketGateway.push_back(clientSocket);

	while (true) {
		// Receive data
		char buff[BUFFSIZE] = { '\0' };
		errorCode = recv(clientSocket, buff, BUFFSIZE, 0);
		lock_guard<mutex> mLock(gatewayMutex);
		if (errorCode == -1 || errorCode == 0) {
			cout << "Socket: " << clientSocket << " connection terminate" << endl;
			close(clientSocket);

			index = findSocket(clientSocket);
			socketGateway.erase(socketGateway.begin() + index);

			return;
		}
		cout << "Socket: " << clientSocket << " recv size: " << errorCode << endl;
		cout << "data: " << (int)buff[0] << (int)buff[1] << (int)buff[2] << (int)buff[3] << &buff[4] << endl;
		//


		// Package check
		// if index[0] == 1, server handle it
		if (buff[0] == 1) {
			// if index[3] == 1, buff is ack
			if (buff[3] == 1) {
				cout << "ack" << endl;
				// get index of buff in carInfoSend
				index = findCarInfo(buff[1], carInfoSend);
				// update package number
				if (carInfoSend[index].packageNum == buff[2]) {
					carInfoSend[index].changePackageNum();
				}

			// buff is instruction from car
			}else {
				// get index of buff in carInfoSend
				index = findCarInfo(buff[1], carInfoReceive);
				// car isn't in the carInfoRecv
				if (index == -1) {
					// add, update and send

					switch (buff[3]) {
					case 2:
						int id, state;
						char* endP;
						id = (int)strtol(&buff[4], &endP, 10);
						state = (int)strtol(endP + 1, &endP, 10);
						stateUpdate(id, state);

						// make ack package
						CarInfo carInfo;
						carInfo.id = buff[1];
						carInfo.packageNum = buff[2];
						carInfo.intMessageSize = 4;
						for (int i = 0; i < BUFFSIZE; i++) {
							carInfo.buff[i] = buff[i];
						}
						carInfo.message[0] = 2;
						carInfo.message[1] = buff[1];
						carInfo.message[2] = buff[2];
						carInfo.message[3] = 1;

						carInfoReceive.push_back(carInfo);
						cout << (int)carInfo.message[0] << (int)carInfo.message[1] << (int)carInfo.message[2] << (int)carInfo.message[3];
						send(clientSocket, carInfo.message, carInfo.intMessageSize, 0);
						break;
					case 3:
						cout << "car is broken" << endl;
						break;
					default:
						break;
					}

				// car is in the carInfoRecv
				}else {
					string s1, s2;
					s1 = carInfoReceive[index].buff;
					s2 = buff;
					if (carInfoReceive[index].packageNum == buff[2] && s1 == s2) {
						// resend
						cout << "resend ack" << endl;
						send(clientSocket, carInfoReceive[index].message, carInfoReceive[index].intMessageSize, 0);
					}else {
						// update and send

						switch (buff[3]) {
						case 2:
							int id, state;
							char* endP;
							id = (int)strtol(&buff[4], &endP, 10);
							state = (int)strtol(endP + 1, &endP, 10);
							stateUpdate(id, state);

							for (int i = 0; i < BUFFSIZE; i++) {
								carInfoReceive[index].buff[i] = buff[i];
							}

							carInfoReceive[index].packageNum = carInfoReceive[index].message[2] = buff[2];
							cout << (int)carInfoReceive[index].message[0] << (int)carInfoReceive[index].message[1] << (int)carInfoReceive[index].message[2] << (int)carInfoReceive[index].message[3];
							send(clientSocket, carInfoReceive[index].message, carInfoReceive[index].intMessageSize, 0);

							break;
						case 3:
							cout << "car is broken" << endl;
							break;
						default:
							break;
						}
					}
				}
			}
		}
	}
}

void stateUpdate(int id, int state) {
	cout << "StateUpdate start" << endl;
	lock_guard<mutex> mLock(sqlMutex);

	string idString, stateString;
	idString = "      ";
	stateString = " ";
	sprintf(&idString[0], "%d", id);
	sprintf(&stateString[0], "%d", state);
	stmt->execute("UPDATE transport SET state = " + stateString + " WHERE _id = " + idString);
}

void handleGatewayBack() {
    cout << "Function handleGatewayBack start" << endl;

    while (true) {
        vector<string> message;
        getNewTransport(message);

        for (int i = 0; i < message.size(); i++) {
            cout << "gateway send hane message: " << message[i] << endl;
            new thread(gatewayBackgroundSend, message[i]);
        }
        gatewaySleep();
    }
}

// Find carInfo with id, if exist return the index, else return -1
int findCarInfo(int id, vector<CarInfo> carInfo) {
	for (int i = 0; i < carInfo.size(); i++) {
		if (id == carInfo[i].id) {
			return i;
		}
	}
	return -1;
}

int findSocket(int clientSocket) {
	for (int i = 0; i < socketGateway.size(); i++) {
		if (clientSocket == socketGateway[i]) {
			return i;
		}
	}
	return -1;
}

void getNewTransport(vector<string> &message) {
    cout << endl << "Function getNewTransport start" << endl;
    lock_guard<mutex> mLock(sqlMutex);

    using std::chrono::system_clock;
    time_t tt = system_clock::to_time_t(system_clock::now());

    struct tm* ptm = std::localtime(&tt);

    if (ptm->tm_min >= 50) {
        ptm->tm_min = 0;
        if (ptm->tm_hour == 23) {
            ptm->tm_hour = 0;
        }else {
            ptm->tm_hour++;
        }
    }else if(ptm->tm_min >= 20 && ptm->tm_min < 30) {
        ptm->tm_min = 30;
    }else {
        return;
    }

    ptm->tm_sec = 0;
    char charArrayBuff[80] = {'\0'};
    strftime(charArrayBuff, sizeof(charArrayBuff), "%Y-%m-%d %H:%M:%S", ptm);
    string time(charArrayBuff), header, stringEmpty;
    vector<int> startId, desId;

    header = "\2  \2";
    res = stmt->executeQuery("SELECT * FROM transport WHERE requireTime = \"" + time + "\"");
	for (int i = 0; res->next(); i++) {
		cout << "gateway background have message" << endl;
		header[1] = res->getInt("car_id");
		message.push_back(header);
		message[i].append(res->getString("_id") + ",");
		message[i].append(res->getString("sender") + ",");
		message[i].append(res->getString("receiver") + ",");
		message[i].append(res->getString("key") + ",");
		message[i].append(res->getString("requireTime") + ",");

		startId.push_back(res->getInt("start_id"));
		desId.push_back(res->getInt("des_id"));
	}
	delete res;
	for (int i = 0; i < startId.size(); i++) {
		res = stmt->executeQuery("SELECT * FROM location WHERE _id=" + to_string(startId[i]));
		res->next();
		message[i].append(res->getString("longitude") + ",");
		message[i].append(res->getString("latitude") + ",");
		delete res;
		res = stmt->executeQuery("SELECT * FROM location WHERE _id=" + to_string(desId[i]));
		res->next();
		message[i].append(res->getString("longitude") + ",");
		message[i].append(res->getString("latitude") + ",");
		delete res;
	}
}

void gatewayBackgroundSend(string message) {
	int index;
	index = findCarInfo(message[1], carInfoSend);
	if (index == -1) {
		lock_guard<mutex> mLock(sqlMutex);

		index = carInfoSend.size();

		// make ack package
		CarInfo carInfo;
		carInfo.id = message[1];
		carInfo.packageNum = 1;
		carInfo.intMessageSize = message.size();
		for (int i = 0; i < message.size(); i++) {
			carInfo.message[i] = message[i];
		}
		carInfoSend.push_back(carInfo);
		message[2] = 1;
	}
	else {
		lock_guard<mutex> mLock(sqlMutex);
		message[2] = carInfoSend[index].packageNum;
		for (int i = 0; i < message.size(); i++) {
			carInfoSend[index].message[i] = message[i];
		}
	}

	while (carInfoSend[index].packageNum == message[2]) {
		gatewayMutex.lock();
		cout << "gateway background send message" << endl;
		cout << "data: " << (int)message[0] << (int)message[1] << (int)message[2] << (int)message[3] << endl;
		cout << &message[4] << endl;
		for (int i = 0; i < socketGateway.size(); i++) {
			send(socketGateway[i], &message[0], message.size(), 0);
		}
		gatewayMutex.unlock();
		this_thread::sleep_for(chrono::seconds(10));
	}
	cout << "gateway background send end" << endl;
}

void gatewaySleep() {
	using std::chrono::system_clock;
	time_t tt = system_clock::to_time_t(system_clock::now());

	struct tm * ptm = std::localtime(&tt);
	cout << "Current time: " << put_time(ptm, "%X") << '\n';

	cout << "Waiting for the next time to fetch data...\n";
	if (ptm->tm_min >= 50) {
		ptm->tm_hour++;
		ptm->tm_min = 20;
	}else if (ptm->tm_min >= 20) {
		ptm->tm_min = 50;
	}else {
		ptm->tm_min = 20;
	}
	ptm->tm_sec = 0;
	this_thread::sleep_until(system_clock::from_time_t(mktime(ptm)));

	cout << std::put_time(ptm, "%X") << " reached!\n";
}
